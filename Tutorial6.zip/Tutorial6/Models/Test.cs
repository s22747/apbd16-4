﻿namespace Tutorial6.Models;

public class Test
{
    public int Id { get; set; }
    public string Name { get; set; }
}